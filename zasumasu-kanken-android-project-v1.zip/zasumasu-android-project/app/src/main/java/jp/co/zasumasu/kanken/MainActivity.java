package jp.co.zasumasu.kanken;

import android.app.Activity;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.mlkit.common.MlKitException;
import com.google.mlkit.common.model.DownloadConditions;
import com.google.mlkit.common.model.RemoteModelManager;
import com.google.mlkit.vision.digitalink.recognition.DigitalInkRecognition;
import com.google.mlkit.vision.digitalink.recognition.DigitalInkRecognitionModel;
import com.google.mlkit.vision.digitalink.recognition.DigitalInkRecognitionModelIdentifier;
import com.google.mlkit.vision.digitalink.recognition.DigitalInkRecognizer;
import com.google.mlkit.vision.digitalink.recognition.DigitalInkRecognizerOptions;
import com.google.mlkit.vision.digitalink.recognition.Ink;
import com.google.mlkit.vision.digitalink.recognition.RecognitionResult;

public class MainActivity extends Activity {
    private HandwritingView handwritingView;
    private TextView status;
    private DigitalInkRecognizer recognizer;
    private final String answer = "備";

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(24, 24, 24, 24);

        TextView title = new TextView(this);
        title.setText("ざます先生の漢検道場");
        title.setTextSize(26);
        TextView question = new TextView(this);
        question.setText("書き取り：そなえる → □");
        question.setTextSize(22);
        question.setPadding(0, 28, 0, 16);
        root.addView(title);
        root.addView(question);

        handwritingView = new HandwritingView();
        root.addView(handwritingView, new LinearLayout.LayoutParams(-1, 0, 1));

        status = new TextView(this);
        status.setText("日本語モデルを準備中…");
        status.setTextSize(18);
        status.setPadding(0, 14, 0, 14);
        root.addView(status);

        LinearLayout buttons = new LinearLayout(this);
        Button clear = new Button(this); clear.setText("消す");
        clear.setOnClickListener(v -> { handwritingView.clearInk(); status.setText("もう一度、書きなさい！"); });
        Button check = new Button(this); check.setText("採点する");
        check.setOnClickListener(v -> recognize());
        buttons.addView(clear, new LinearLayout.LayoutParams(0, -2, 1));
        buttons.addView(check, new LinearLayout.LayoutParams(0, -2, 1));
        root.addView(buttons);
        setContentView(root);
        initializeRecognizer();
    }

    private void initializeRecognizer() {
        try {
            DigitalInkRecognitionModelIdentifier id = DigitalInkRecognitionModelIdentifier.fromLanguageTag("ja-JP");
            if (id == null) { status.setText("E001 日本語モデルが見つかりません"); return; }
            DigitalInkRecognitionModel model = DigitalInkRecognitionModel.builder(id).build();
            recognizer = DigitalInkRecognition.getClient(DigitalInkRecognizerOptions.builder(model).build());
            RemoteModelManager.getInstance().download(model, new DownloadConditions.Builder().build())
                .addOnSuccessListener(v -> status.setText("準備完了。『備』を書いて採点しなさい！"))
                .addOnFailureListener(e -> status.setText("E003 モデル取得失敗：" + e.getMessage()));
        } catch (MlKitException e) {
            status.setText("E002 ML Kit初期化失敗：" + e.getMessage());
        } catch (Exception e) {
            status.setText("E001 初期化失敗：" + e.getMessage());
        }
    }

    private void recognize() {
        if (recognizer == null) { status.setText("E001 認識機能が準備できていません"); return; }
        if (handwritingView.isEmpty()) { status.setText("E004 何も書かれていません。逃げてはいけません！"); return; }
        status.setText("採点中…");
        recognizer.recognize(handwritingView.buildInk())
            .addOnSuccessListener(this::grade)
            .addOnFailureListener(e -> status.setText("E005 認識失敗：" + e.getMessage()));
    }

    private void grade(RecognitionResult result) {
        if (result.getCandidates().isEmpty()) { status.setText("E006 認識候補なし。丁寧に、もう一度！"); return; }
        StringBuilder candidates = new StringBuilder();
        for (int i = 0; i < Math.min(3, result.getCandidates().size()); i++) {
            if (i > 0) candidates.append(" / ");
            candidates.append(result.getCandidates().get(i).getText());
        }
        String top = result.getCandidates().get(0).getText();
        if (answer.equals(top)) status.setText("⭕ 正解ざます！ 認識：" + candidates);
        else status.setText("❌ 不正解です！ 認識：" + candidates + "\n正解は『" + answer + "』。もう一度、書きなさい！");
    }

    private class HandwritingView extends View {
        private final Paint inkPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint gridPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final java.util.ArrayList<Ink.Stroke> strokes = new java.util.ArrayList<>();
        private final java.util.ArrayList<Path> paths = new java.util.ArrayList<>();
        private Ink.Stroke.Builder currentStroke;
        private Path currentPath;

        HandwritingView() {
            super(MainActivity.this);
            setBackgroundColor(Color.WHITE);
            inkPaint.setColor(Color.BLACK); inkPaint.setStyle(Paint.Style.STROKE); inkPaint.setStrokeWidth(10f);
            inkPaint.setStrokeCap(Paint.Cap.ROUND); inkPaint.setStrokeJoin(Paint.Join.ROUND);
            gridPaint.setColor(0xFFE0E0E0); gridPaint.setStrokeWidth(2f);
        }
        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            canvas.drawLine(getWidth()/2f, 0, getWidth()/2f, getHeight(), gridPaint);
            canvas.drawLine(0, getHeight()/2f, getWidth(), getHeight()/2f, gridPaint);
            for (Path p : paths) canvas.drawPath(p, inkPaint);
            if (currentPath != null) canvas.drawPath(currentPath, inkPaint);
        }
        @Override public boolean onTouchEvent(MotionEvent e) {
            float x=e.getX(), y=e.getY(); long t=System.currentTimeMillis();
            switch(e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    currentStroke=Ink.Stroke.builder(); currentStroke.addPoint(Ink.Point.create(x,y,t));
                    currentPath=new Path(); currentPath.moveTo(x,y); invalidate(); return true;
                case MotionEvent.ACTION_MOVE:
                    if(currentStroke!=null){ currentStroke.addPoint(Ink.Point.create(x,y,t)); currentPath.lineTo(x,y); invalidate(); }
                    return true;
                case MotionEvent.ACTION_UP:
                    if(currentStroke!=null){ currentStroke.addPoint(Ink.Point.create(x,y,t)); strokes.add(currentStroke.build()); paths.add(currentPath); currentStroke=null; currentPath=null; invalidate(); }
                    return true;
                default: return true;
            }
        }
        Ink buildInk(){ Ink.Builder b=Ink.builder(); for(Ink.Stroke s:strokes)b.addStroke(s); return b.build(); }
        boolean isEmpty(){ return strokes.isEmpty(); }
        void clearInk(){ strokes.clear(); paths.clear(); currentStroke=null; currentPath=null; invalidate(); }
    }
}
